import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-range',
  templateUrl: './customer-range.component.html',
  styleUrls: ['./customer-range.component.scss'],
})
export class CustomerRangeComponent implements OnInit {
  data: any = [];
  constructor() {}

  ngOnInit(): void {}
}
