import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plc-alarams',
  templateUrl: './plc-alarams.component.html',
  styleUrls: ['./plc-alarams.component.scss'],
})
export class PlcAlaramsComponent implements OnInit {
  data: any = [];
  constructor() {}

  ngOnInit(): void {}
}
