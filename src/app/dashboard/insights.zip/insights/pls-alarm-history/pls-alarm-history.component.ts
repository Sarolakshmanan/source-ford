import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pls-alarm-history',
  templateUrl: './pls-alarm-history.component.html',
  styleUrls: ['./pls-alarm-history.component.scss']
})
export class PlsAlarmHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
