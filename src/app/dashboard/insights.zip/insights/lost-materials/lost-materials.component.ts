import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lost-materials',
  templateUrl: './lost-materials.component.html',
  styleUrls: ['./lost-materials.component.scss']
})
export class LostMaterialsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
