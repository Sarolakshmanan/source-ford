import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-against-material',
  templateUrl: './user-against-material.component.html',
  styleUrls: ['./user-against-material.component.scss'],
})
export class UserAgainstMaterialComponent implements OnInit {
  data: any = [];
  constructor() {}

  ngOnInit(): void {}
}
