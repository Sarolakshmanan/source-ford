import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-against',
  templateUrl: './user-against.component.html',
  styleUrls: ['./user-against.component.scss']
})
export class UserAgainstComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
